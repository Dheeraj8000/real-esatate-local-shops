# LOCAL-BAZAAR
"A local e-commerce platform for connecting shopkeepers and customers. Built using HTML, CSS, and JavaScript."
